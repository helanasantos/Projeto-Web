# Lista de Exercícios Complementares

### Reforço: Estrutura de Repetição

